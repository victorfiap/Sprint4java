package br.com.fiap.main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.model.Pecas;

public class TesteArrayPecas {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {

		// INSTANCIAR OBJETOS

		List<Pecas> ListaPecas = new ArrayList<Pecas>();
		Pecas objPecas = null;

		do {
			objPecas = new Pecas();
			objPecas.setCatraca(texto("Digite o tipo da catraca"));
			objPecas.setManopla(texto("Informe o tipo da manopla"));
			objPecas.setMarcha(texto("Digite o tipo da marcha"));
			objPecas.setPedal(texto("Digite o tipo do pedal"));
			objPecas.setPneuFrontal(texto("Qual tipo do pneu frontal?"));
			objPecas.setPneuTraseiro(texto("E qual o tipo de pneu trasseiro"));
			objPecas.setBanco(texto("Digite o tipo do banco"));
			objPecas.setGuidao(texto("Informe o tipo de guidão"));

			ListaPecas.add(objPecas);

		} while (JOptionPane.showConfirmDialog(null, "Adicionar mais informação?", "INFORMAÇÕES DAS PEÇAS DA BIKE",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);

		// SAÍDA

		for (Pecas p : ListaPecas) {
			System.out.println("Catraca: " + p.getCatraca() + "\nManopla: " + p.getManopla() + "\nMarcha: "
					+ p.getMarcha() + "\nPedal: " + p.getPedal() + "\nPneu frontal: " + p.getPneuFrontal()
					+ "\nPneu trasseiro: " + p.getPneuTraseiro() + "\nBanco? " + p.getBanco() + "\nGuidão: "
					+ p.getGuidao());

		}

	}

}
