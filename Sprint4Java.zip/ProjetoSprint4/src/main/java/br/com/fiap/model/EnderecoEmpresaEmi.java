package br.com.fiap.model;

import br.com.fiap.model.Cliente;

public class EnderecoEmpresaEmi extends Cliente{
	
	// VISIBLIDADE, TIPO DE DADO E O NOME DA VARIÁVEL
	
	private String logradouroEmpresaEmi;
	private String cepEmpresaEmi;
	private int numEmpresaEmi;
	private String bairroEmpresaEmi;
	private String estadoEmpresaEmi;
	private String municipioEmpresaEmi;
	
	// MÉTODOS CONSTRUTORES VAZIO, CHEIO , COM ATRIBUTOS DA PROÓPRIA CLASSE E COM HERANÇA
	
	public EnderecoEmpresaEmi() {
		super();
	}

	public EnderecoEmpresaEmi(String logradouroEmpresaEmi, String cepEmpresaEmi, int numEmpresaEmi,
			String bairroEmpresaEmi, String estadoEmpresaEmi, String municipioEmpresaEmi) {
		super();
		this.logradouroEmpresaEmi = logradouroEmpresaEmi;
		this.cepEmpresaEmi = cepEmpresaEmi;
		this.numEmpresaEmi = numEmpresaEmi;
		this.bairroEmpresaEmi = bairroEmpresaEmi;
		this.estadoEmpresaEmi = estadoEmpresaEmi;
		this.municipioEmpresaEmi = municipioEmpresaEmi;
	}
	
	public EnderecoEmpresaEmi(String nomeCliente, int idade, double rendaMedia, String cpf, String rg, String cnh,
			String logradouroEmpresaEmi, String cepEmpresaEmi, int numEmpresaEmi, String bairroEmpresaEmi,
			String estadoEmpresaEmi, String municipioEmpresaEmi) {
		super(nomeCliente, idade, rendaMedia, cpf, rg, cnh);
		this.logradouroEmpresaEmi = logradouroEmpresaEmi;
		this.cepEmpresaEmi = cepEmpresaEmi;
		this.numEmpresaEmi = numEmpresaEmi;
		this.bairroEmpresaEmi = bairroEmpresaEmi;
		this.estadoEmpresaEmi = estadoEmpresaEmi;
		this.municipioEmpresaEmi = municipioEmpresaEmi;
	}

	// SETTERS E GETTERS
	
	public String getLogradouroEmpresaEmi() {
		return logradouroEmpresaEmi;
	}

	public void setLogradouroEmpresaEmi(String logradouroEmpresaEmi) {
		this.logradouroEmpresaEmi = logradouroEmpresaEmi;
	}

	public String getCepEmpresaEmi() {
		return cepEmpresaEmi;
	}

	public void setCepEmpresaEmi(String cepEmpresaEmi) {
		this.cepEmpresaEmi = cepEmpresaEmi;
	}

	public int getNumEmpresaEmi() {
		return numEmpresaEmi;
	}

	public void setNumEmpresaEmi(int numEmpresaEmi) {
		this.numEmpresaEmi = numEmpresaEmi;
	}

	public String getBairroEmpresaEmi() {
		return bairroEmpresaEmi;
	}

	public void setBairroEmpresaEmi(String bairroEmpresaEmi) {
		this.bairroEmpresaEmi = bairroEmpresaEmi;
	}

	public String getEstadoEmpresaEmi() {
		return estadoEmpresaEmi;
	}

	public void setEstadoEmpresaEmi(String estadoEmpresaEmi) {
		this.estadoEmpresaEmi = estadoEmpresaEmi;
	}

	public String getMunicipioEmpresaEmi() {
		return municipioEmpresaEmi;
	}

	public void setMunicipioEmpresaEmi(String municipioEmpresaEmi) {
		this.municipioEmpresaEmi = municipioEmpresaEmi;
	}
	

}
