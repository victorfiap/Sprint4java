package br.com.fiap.model;

public class Cliente {
	
	// VISIBLIDADE, TIPO DE DADO E O NOME DA VARIÁVEL

		private String nomeCliente;
		private int idade;
		private double rendaMedia;
		private String cpf;
		private String rg;
		private String cnh;
		private EnderecoCliente enderecoCliente;

		// MÉTODOS CONSTRUTOR VAZIO, CHEIO E COM ATRIBUTOS DA PRÓPRIA CLASSE

		public Cliente() {
			super();
		}

		public Cliente(String nomeCliente, int idade, double rendaMedia, String cpf, String rg, String cnh,
				EnderecoCliente enderecoCliente) {
			super();
			this.nomeCliente = nomeCliente;
			this.idade = idade;
			this.rendaMedia = rendaMedia;
			this.cpf = cpf;
			this.rg = rg;
			this.cnh = cnh;
			this.enderecoCliente = enderecoCliente;
		}

		public Cliente(String nomeCliente, int idade, double rendaMedia, String cpf, String rg, String cnh) {
			super();
			this.nomeCliente = nomeCliente;
			this.idade = idade;
			this.rendaMedia = rendaMedia;
			this.cpf = cpf;
			this.rg = rg;
			this.cnh = cnh;
		}

		
		
		// SETTERS E GETTERS

		public String getNomeCliente() {
			return nomeCliente;
		}

		public void setNomeCliente(String nomeCliente) {
			this.nomeCliente = nomeCliente;
		}

		public int getIdade() {
			return idade;
		}

		public void setIdade(int idade) {
			this.idade = idade;
		}

		public double getRendaMedia() {
			return rendaMedia;
		}

		public void setRendaMedia(double rendaMedia) {
			this.rendaMedia = rendaMedia;
		}

		public String getCpf() {
			return cpf;
		}

		public void setCpf(String cpf) {
			this.cpf = cpf;
		}

		public String getRg() {
			return rg;
		}

		public void setRg(String rg) {
			this.rg = rg;
		}

		public String getCnh() {
			return cnh;
		}

		public void setCnh(String cnh) {
			this.cnh = cnh;
		}

		public EnderecoCliente getEnderecoCliente() {
			return enderecoCliente;
		}

		public void setEnderecoCliente(EnderecoCliente enderecoCliente) {
			this.enderecoCliente = enderecoCliente;

		}
	}


