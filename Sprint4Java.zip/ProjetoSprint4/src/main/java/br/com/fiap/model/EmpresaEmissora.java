package br.com.fiap.model;

public class EmpresaEmissora extends Cliente {

	// VISIBLIDADE, TIPO DE DADO E O NOME DA VARIÁVEL

	private String nomeEmpresaEmi;
	private EnderecoEmpresaEmi enderecoEmpresaEmi;
	private String cnpj;

	// MÉTODOS CONSTRUTORES VAZIO, CHEIO, COM ATRIBUTOS DA PROÓPRIA CLASSE E COM HERANÇA

	public EmpresaEmissora() {
		super();
	}

	public EmpresaEmissora(String nomeEmpresa, EnderecoEmpresaEmi enderecoEmpresaEmi, String cnpj) {
		super();
		this.nomeEmpresaEmi = nomeEmpresa;
		this.enderecoEmpresaEmi = enderecoEmpresaEmi;
		this.cnpj = cnpj;
	}

	public EmpresaEmissora(String nomeEmpresa, String cnpj) {
		super();
		this.nomeEmpresaEmi = nomeEmpresa;
		this.cnpj = cnpj;
	}
	
	public EmpresaEmissora(String nomeCliente, int idade, double rendaMedia, String cpf, String rg, String cnh,
			String nomeEmpresa, EnderecoEmpresaEmi enderecoEmpresaEmi, String cnpj) {
		super(nomeCliente, idade, rendaMedia, cpf, rg, cnh);
		this.nomeEmpresaEmi = nomeEmpresa;
		this.enderecoEmpresaEmi = enderecoEmpresaEmi;
		this.cnpj = cnpj;
	}

	// SETTERS E GETTERS

	public String getNomeEmpresa() {
		return nomeEmpresaEmi;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresaEmi = nomeEmpresa;
	}

	public EnderecoEmpresaEmi getEnderecoEmpresaEmi() {
		return enderecoEmpresaEmi;
	}

	public void setEnderecoEmpresaEmi(EnderecoEmpresaEmi enderecoEmpresaEmi) {
		this.enderecoEmpresaEmi = enderecoEmpresaEmi;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

}
