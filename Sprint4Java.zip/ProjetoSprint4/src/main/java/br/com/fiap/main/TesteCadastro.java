package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.model.Cliente;

public class TesteCadastro {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		// INSTANCIAR OBJETOS

		Cliente objCliente = new Cliente();

		ClienteDAO dao = new ClienteDAO();

		objCliente.setNomeCliente(texto("Nome do cliente"));
		objCliente.setIdade(inteiro("Idade do cliente"));
		objCliente.setRendaMedia(real("Renda media do cliente"));
		objCliente.setCpf(texto("CPF do cliente"));
		objCliente.setRg(texto("RG do cliente"));
		objCliente.setCnh(texto("Cnh do cliente"));

		System.out.println(dao.inserir(objCliente));

	}

}
