package br.com.fiap.main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.model.Produto;

public class TesteArrayProduto {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {

		// INSTANCIAR OBJETOS

		List<Produto> ListaProduto = new ArrayList<Produto>();
		Produto objProduto = null;

		do {
			objProduto = new Produto();
			objProduto.setNomeProduto(texto("Digite o nome do produto"));
			objProduto.setMarcaProduto(texto("Informe a marca do produto"));
			objProduto.setCor(texto("Informe a cor da bike"));
			objProduto.setValor(real("Digite o valor da bike"));
			objProduto.setTipo(texto("Informe o tipo do produto"));

			ListaProduto.add(objProduto);

		} while (JOptionPane.showConfirmDialog(null, "Adicionar mais informação do produto?", "INFORMAÇÕES DA BIKE",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);

		// SAÍDA

		for (Produto p : ListaProduto) {
			System.out.println("Nome do produto: " + p.getNomeProduto() + "\nMarca do produto: " + p.getMarcaProduto()
					+ "\nCor: " + p.getCor() + "\nValor: " + p.getValor() + "\nTipo do produto: " + p.getTipo());
		}

	}

}
