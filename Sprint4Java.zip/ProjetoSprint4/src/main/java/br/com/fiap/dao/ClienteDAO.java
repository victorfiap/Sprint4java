package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.model.Cliente;

public class ClienteDAO {

	public Connection minhaconexao;

	public ClienteDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaconexao = new ConexaoFactory().conexao();
	}

	// MÉTODO INSERT

	public String inserir(Cliente cliente) throws SQLException {
		PreparedStatement stmt = minhaconexao.prepareStatement("Insert into T_FIAP_CLIENTE values (?,?,?,?,?,?) ");
		stmt.setString(1, cliente.getNomeCliente());
		stmt.setInt(2, cliente.getIdade());
		stmt.setDouble(3, cliente.getRendaMedia());
		stmt.setString(4, cliente.getCpf());
		stmt.setString(5, cliente.getRg());
		stmt.setString(6, cliente.getCnh());
		stmt.execute();
		stmt.close();

		return "Cadastrado com sucesso!!!";

	}

	// DELETE

	public String deletar(Cliente cliente) throws SQLException {
		PreparedStatement stmt = minhaconexao.prepareStatement("Delete from T_FIAP_CLIENTE where NOME_CLIENTE = ?");
		stmt.setString(1, cliente.getNomeCliente());
		stmt.execute();
		stmt.close();

		return "Deletado com sucesso!!!";

	}

	// UPDATE

	public String alterar(Cliente cliente) throws SQLException {
		PreparedStatement stmt = minhaconexao
				.prepareStatement("Update T_FIAP_CLIENTE set IDADE_CLIENTE = ?, RENDA_CLIENTE = ?, CPF_CLIENTE = ?, "
						+ "RG_CLIENTE = ?, CNH_CLIENTE = ? where NOME_CLIENTE = ?");
		stmt.setInt(1, cliente.getIdade());
		stmt.setDouble(2, cliente.getRendaMedia());
		stmt.setString(3, cliente.getCpf());
		stmt.setString(4, cliente.getRg());
		stmt.setString(5, cliente.getCnh());
		stmt.setString(6, cliente.getNomeCliente());
		stmt.executeUpdate();
		stmt.close();

		return "Alterado com sucesso!!!";
	}

	// SELECT

	public List<Cliente> selecionar() throws SQLException {
		List<Cliente> listaCliente = new ArrayList<Cliente>();
		PreparedStatement stmt = minhaconexao.prepareStatement("SELECT * FROM T_FIAP_CLIENTE");
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			Cliente cliente = new Cliente();
			cliente.setNomeCliente(rs.getNString(1));
			cliente.setIdade(rs.getInt(2));
			cliente.setRendaMedia(rs.getDouble(3));
			cliente.setCpf(rs.getString(4));
			cliente.setRg(rs.getString(5));
			cliente.setCnh(rs.getString(6));
			listaCliente.add(cliente);
		}
		return listaCliente;

	}

}