package br.com.fiap.model;

public class Pecas extends Cliente {

	// VISIBLIDADE, TIPO DE DADO E O NOME DA VARIÁVEL

	private String catraca;
	private String manopla;
	private String marcha;
	private String pedal;
	private String pneuFrontal;
	private String pneuTraseiro;
	private String banco;
	private String guidao;

	// MÉTODOS CONSTRUTORES VAZIO, CHEIO , COM ATRIBUTOS DA PROÓPRIA CLASSE E COM HERANÇA

	public Pecas() {
		super();
	}

	public Pecas(String catraca, String manopla, String marcha, String pedal, String pneuFrontal, String pneuTraseiro,
			String banco, String guidao) {
		super();
		this.catraca = catraca;
		this.manopla = manopla;
		this.marcha = marcha;
		this.pedal = pedal;
		this.pneuFrontal = pneuFrontal;
		this.pneuTraseiro = pneuTraseiro;
		this.banco = banco;
		this.guidao = guidao;
	}

	public Pecas(String nomeCliente, int idade, double rendaMedia, String cpf, String rg, String cnh, String catraca,
			String manopla, String marcha, String pedal, String pneuFrontal, String pneuTraseiro, String banco,
			String guidao) {
		super(nomeCliente, idade, rendaMedia, cpf, rg, cnh);
		this.catraca = catraca;
		this.manopla = manopla;
		this.marcha = marcha;
		this.pedal = pedal;
		this.pneuFrontal = pneuFrontal;
		this.pneuTraseiro = pneuTraseiro;
		this.banco = banco;
		this.guidao = guidao;
	}

	// SETTERS E GETTERS

	public String getCatraca() {
		return catraca;
	}

	public void setCatraca(String catraca) {
		this.catraca = catraca;
	}

	public String getManopla() {
		return manopla;
	}

	public void setManopla(String manopla) {
		this.manopla = manopla;
	}

	public String getMarcha() {
		return marcha;
	}

	public void setMarcha(String marcha) {
		this.marcha = marcha;
	}

	public String getPedal() {
		return pedal;
	}

	public void setPedal(String pedal) {
		this.pedal = pedal;
	}

	public String getPneuFrontal() {
		return pneuFrontal;
	}

	public void setPneuFrontal(String pneuFrontal) {
		this.pneuFrontal = pneuFrontal;
	}

	public String getPneuTraseiro() {
		return pneuTraseiro;
	}

	public void setPneuTraseiro(String pneuTraseiro) {
		this.pneuTraseiro = pneuTraseiro;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getGuidao() {
		return guidao;
	}

	public void setGuidao(String guidao) {
		this.guidao = guidao;
	}

}
