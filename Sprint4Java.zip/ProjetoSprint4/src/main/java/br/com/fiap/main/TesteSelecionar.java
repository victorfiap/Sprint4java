package br.com.fiap.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.model.Cliente;

public class TesteSelecionar {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		// INSTANCIAR OBJETOS
		
		ClienteDAO dao = new ClienteDAO();
		
		List<Cliente> listaClientes = (ArrayList<Cliente>) dao.selecionar();
		
		if (listaClientes != null) {
			// FOREACH
			for(Cliente cliente : listaClientes) {
				System.out.println(cliente.getNomeCliente() + " " + 
									cliente.getIdade() + " " + 
									cliente.getRendaMedia() + " " +
									cliente.getCpf() + " " + 
									cliente.getRg() + " " +
									cliente.getCnh() + " ");
			}
		}
	}

}
