package br.com.fiap.main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.model.EnderecoCliente;

public class TesteArrayEnderecoCliente {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {

		// INSTANCIAR

		List<EnderecoCliente> listaEnderecoCliente = new ArrayList<EnderecoCliente>();
		EnderecoCliente objEnderecoCliente = null;

		do {
			objEnderecoCliente = new EnderecoCliente();
			objEnderecoCliente.setLogradouroCliente(texto("Informe o logradouro do cliente"));
			objEnderecoCliente.setCepCliente(texto("Informe o cep do cliente"));
			objEnderecoCliente.setNumCliente(inteiro("Digite o numero de acesso do cliente"));
			objEnderecoCliente.setBairroCliente(texto("Digite o bairro do cliente"));
			objEnderecoCliente.setEstadoCliente(texto("Informe o estado do cliente"));
			objEnderecoCliente.setMunicipioCliente(texto("Digite o municipio do cliente"));

			listaEnderecoCliente.add(objEnderecoCliente);

		} while (JOptionPane.showConfirmDialog(null, "Adicionar mais informação?",
				"INFORMAÇÃO DO LOGRADOURO DA EMPRESA", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);

		// SAÍDA

		for (EnderecoCliente e : listaEnderecoCliente) {
			System.out.println("INFORMAÇÕES DO LOGRADOURO DO CLIENTE");
			System.out.println("\nLogradouro: " + e.getLogradouroCliente() + "\nCep do cliente: " + e.getCepCliente()
					+ "\nNumero do cliente: " + e.getNumCliente() + "\nBairro: " + e.getBairroCliente() + "\nEstado: "
					+ e.getEstadoCliente() + "\nMunicipio: " + e.getMunicipioCliente());
		}

	}

}
