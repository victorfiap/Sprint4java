package br.com.fiap.model;

public class EnderecoCliente extends Cliente {

	// VISIBLIDADE, TIPO DE DADO E O NOME DA VARIÁVEL

	private String logradouroCliente;
	private String cepCliente;
	private int numCliente;
	private String bairroCliente;
	private String estadoCliente;
	private String municipioCliente;

	// MÉTODOS CONSTRUTORES VAZIO, CHEIO, COM ATRIBUTOS DA PROÓPRIA CLASSE E COM HERANÇA

	public EnderecoCliente() {
		super();
	}

	public EnderecoCliente(String logradouroCliente, String cepCliente, int numCliente, String bairroCliente,
			String estadoCliente, String municipioCliente) {
		super();
		this.logradouroCliente = logradouroCliente;
		this.cepCliente = cepCliente;
		this.numCliente = numCliente;
		this.bairroCliente = bairroCliente;
		this.estadoCliente = estadoCliente;
		this.municipioCliente = municipioCliente;
	}
	
	public EnderecoCliente(String nomeCliente, int idade, double rendaMedia, String cpf, String rg, String cnh,
			String logradouroCliente, String cepCliente, int numCliente, String bairroCliente, String estadoCliente,
			String municipioCliente) {
		super(nomeCliente, idade, rendaMedia, cpf, rg, cnh);
		this.logradouroCliente = logradouroCliente;
		this.cepCliente = cepCliente;
		this.numCliente = numCliente;
		this.bairroCliente = bairroCliente;
		this.estadoCliente = estadoCliente;
		this.municipioCliente = municipioCliente;
	}

	// SETTERS E GETTERS

	public String getLogradouroCliente() {
		return logradouroCliente;
	}

	public void setLogradouroCliente(String logradouroCliente) {
		this.logradouroCliente = logradouroCliente;
	}

	public String getCepCliente() {
		return cepCliente;
	}

	public void setCepCliente(String cepCliente) {
		this.cepCliente = cepCliente;
	}

	public int getNumCliente() {
		return numCliente;
	}

	public void setNumCliente(int numCliente) {
		this.numCliente = numCliente;
	}

	public String getBairroCliente() {
		return bairroCliente;
	}

	public void setBairroCliente(String bairroCliente) {
		this.bairroCliente = bairroCliente;
	}

	public String getEstadoCliente() {
		return estadoCliente;
	}

	public void setEstadoCliente(String estadoCliente) {
		this.estadoCliente = estadoCliente;
	}

	public String getMunicipioCliente() {
		return municipioCliente;
	}

	public void setMunicipioCliente(String municipioCliente) {
		this.municipioCliente = municipioCliente;
	}

}
