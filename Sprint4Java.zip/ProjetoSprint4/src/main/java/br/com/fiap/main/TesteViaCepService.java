package br.com.fiap.main;

import java.io.IOException;

import javax.swing.JOptionPane;

import org.apache.http.client.ClientProtocolException;

import br.com.fiap.model.EnderecoAPI;
import br.com.fiap.service.ViaCepservice;

public class TesteViaCepService {

	public static void main(String[] args) throws ClientProtocolException, IOException {

		// INSTANCIAR OBJETOS
		
		ViaCepservice viaCep = new ViaCepservice();
		
		String cep = JOptionPane.showInputDialog("Informe o cep a ser pesquisado");
		
		EnderecoAPI endereco = viaCep.getEndereco(cep);
		
		System.out.println(endereco);
		
	}

}
