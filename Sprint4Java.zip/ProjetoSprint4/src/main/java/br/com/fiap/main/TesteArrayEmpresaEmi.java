package br.com.fiap.main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.model.EmpresaEmissora;

public class TesteArrayEmpresaEmi {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {

		// INSTANCIAR

		List<EmpresaEmissora> ListaEmpresaEmissora = new ArrayList<EmpresaEmissora>();
		EmpresaEmissora objEmpresaEmissora = null;

		do {
			objEmpresaEmissora = new EmpresaEmissora();
			objEmpresaEmissora.setNomeEmpresa(texto("Digite o nome da empresa"));
			objEmpresaEmissora.setCnpj(texto("Informe o cnpj da empresa"));

			ListaEmpresaEmissora.add(objEmpresaEmissora);

		} while (JOptionPane.showConfirmDialog(null, "Adicionar mais informação?", "INFORMAÇÃO DA EMPRESA",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);

		// SAÍDA

		for (EmpresaEmissora e : ListaEmpresaEmissora) {
			System.out.println("INFORMAÇÕES DA EMPRESA");
			System.out.println("\nNome da empresa: " + e.getNomeEmpresa() + "\nCnpj: " + e.getCnpj());
		}

	}

}
