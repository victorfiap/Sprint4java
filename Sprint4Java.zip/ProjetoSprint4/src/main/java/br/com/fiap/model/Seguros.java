package br.com.fiap.model;

import br.com.fiap.model.Cliente;

public class Seguros extends Cliente{

	// VISIBLIDADE, TIPO DE DADO E O NOME DA VARIÁVEL

	private String tipoSeguro;
	private String coberturaSeguro;
	private double valorSeguro;
	private int dataInicio;
	private int dataVencimento;

	// MÉTODOS CONSTRUTORES VAZIO, CHEIO , COM ATRIBUTOS DA PROÓPRIA CLASSE E COM HERANÇA

	public Seguros() {
		super();
	}

	public Seguros(String tipoSeguro, String coberturaSeguro, double valorSeguro, int dataInicio, int dataVencimento) {
		super();
		this.tipoSeguro = tipoSeguro;
		this.coberturaSeguro = coberturaSeguro;
		this.valorSeguro = valorSeguro;
		this.dataInicio = dataInicio;
		this.dataVencimento = dataVencimento;
	}

	public Seguros(String nomeCliente, int idade, double rendaMedia, String cpf, String rg, String cnh,
			String tipoSeguro, String coberturaSeguro, double valorSeguro, int dataInicio, int dataVencimento) {
		super(nomeCliente, idade, rendaMedia, cpf, rg, cnh);
		this.tipoSeguro = tipoSeguro;
		this.coberturaSeguro = coberturaSeguro;
		this.valorSeguro = valorSeguro;
		this.dataInicio = dataInicio;
		this.dataVencimento = dataVencimento;
	}

	// SETTERS E GETTERS

	public String getTipoSeguro() {
		return tipoSeguro;
	}

	public void setTipoSeguro(String tipoSeguro) {
		this.tipoSeguro = tipoSeguro;
	}

	public String getCoberturaSeguro() {
		return coberturaSeguro;
	}

	public void setCoberturaSeguro(String coberturaSeguro) {
		this.coberturaSeguro = coberturaSeguro;
	}

	public double getValorSeguro() {
		return valorSeguro;
	}

	public void setValorSeguro(double valorSeguro) {
		this.valorSeguro = valorSeguro;
	}

	public int getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(int dataInicio) {
		this.dataInicio = dataInicio;
	}

	public int getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(int dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

}
