package br.com.fiap.model;

public class Produto extends Cliente {

	// VISIBLIDADE, TIPO DE DADO E O NOME DA VARIÁVEL

	private String nomeProduto;
	private String marcaProduto;
	private Pecas pecas;
	private String cor;
	private double valor;
	private String tipo;

	// MÉTODOS CONSTRUTORES VAZIO, CHEIO , COM ATRIBUTOS DA PROÓPRIA CLASSE E COM HERANÇA

	public Produto() {
		super();
	}

	public Produto(String nomeProduto, String marcaProduto, Pecas pecas, String cor, double valor, String tipo) {
		super();
		this.nomeProduto = nomeProduto;
		this.marcaProduto = marcaProduto;
		this.pecas = pecas;
		this.cor = cor;
		this.valor = valor;
		this.tipo = tipo;
	}

	public Produto(String nomeProduto, String marcaProduto, String cor, double valor, String tipo) {
		super();
		this.nomeProduto = nomeProduto;
		this.marcaProduto = marcaProduto;
		this.cor = cor;
		this.valor = valor;
		this.tipo = tipo;
	}
	
	
	public Produto(String nomeCliente, int idade, double rendaMedia, String cpf, String rg, String cnh,
			String nomeProduto, String marcaProduto, Pecas pecas, String cor, double valor, String tipo) {
		super(nomeCliente, idade, rendaMedia, cpf, rg, cnh);
		this.nomeProduto = nomeProduto;
		this.marcaProduto = marcaProduto;
		this.pecas = pecas;
		this.cor = cor;
		this.valor = valor;
		this.tipo = tipo;
	}

	// SETTERS E GETTERS

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public String getMarcaProduto() {
		return marcaProduto;
	}

	public void setMarcaProduto(String marcaProduto) {
		this.marcaProduto = marcaProduto;
	}

	public Pecas getPecas() {
		return pecas;
	}

	public void setPecas(Pecas pecas) {
		this.pecas = pecas;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}
