package br.com.fiap.main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.model.Seguros;

public class TesteArraySeguros {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {

		// INSTANCIAR OBJETOS

		List<Seguros> listaSeguros = new ArrayList<Seguros>();
		Seguros objSeguros = null;

		do {
			objSeguros = new Seguros();
			objSeguros.setTipoSeguro(texto("Digite o tipo de seguro desejado"));
			objSeguros.setCoberturaSeguro(texto("Informe a cobertura de seguros"));
			objSeguros.setValorSeguro(real("Digite o valor passado do seguro"));
			objSeguros.setDataInicio(inteiro("Informe a data de inicio"));
			objSeguros.setDataVencimento(inteiro("Digite a data de vencimento"));

			listaSeguros.add(objSeguros);

		} while (JOptionPane.showConfirmDialog(null, "Adicionar mais informação?", "INFORMAÇÕES DO SEGURO",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);

		// SAÍDA

		for (Seguros s : listaSeguros) {
			System.out.println("Tipo do seguro: " + s.getTipoSeguro() + "\nCobertura do seguro: "
					+ s.getCoberturaSeguro() + "\nValor do seguro: " + s.getValorSeguro() + "\nData de início: "
					+ s.getDataInicio() + "\nData de vencimento: " + s.getDataVencimento());
		}

	}

}
