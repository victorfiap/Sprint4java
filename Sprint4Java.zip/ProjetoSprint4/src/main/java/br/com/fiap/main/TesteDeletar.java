package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.model.Cliente;

public class TesteDeletar {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Cliente objCliente = new Cliente();

		ClienteDAO dao = new ClienteDAO();

		objCliente.setNomeCliente(texto("Nome do cliente a ser deletado"));

		System.out.println(dao.deletar(objCliente));


	}

}
